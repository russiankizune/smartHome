package com.example.pract1selin;

import com.google.gson.annotations.SerializedName;

public class Light
{
    private int id;

    public int getId() {
        return id;
    }

    private boolean isOn;

    public boolean isOn() {
        return isOn;
    }

    private int power;

    public int getPower() {
        return power;
    }
}
