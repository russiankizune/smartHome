package com.example.pract1selin;

import java.util.List;

public class LightsList
{
    private List<Light> lights;

    public List<Light> getLights()
    {
        return lights;
    }

    public void setLights(List<Light> lights)
    {
        this.lights = lights;
    }
}
